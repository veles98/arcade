---
name: prompt-context
description: Fills a role / context / goal / input / constraints / example / output template with the user so any AI understands the request on the first try, asks up to 3 questions if something is missing, then answers. Use when the user says the AI does not understand them, gives generic answers, or asks for a prompt template.
---

# قالب البرومبت (السياق)

قالب تملاه وتبعته، والذكاء يفهم طلبك من أول مرة.

## طريقة الشغل
- المرجع تحت هو الطريقة اللي استخدمها أنس (@anas.ai.ar) في الريل. طبّقها على طلب المستخدم.
- أي شي بين قوسين مربعة [مثل كذا] يتبدّل بكلام المستخدم. إذا ناقص، اسأله سؤال واحد قصير قبل ما تبدأ.
- رد بلهجة المستخدم، وخل الخطوات قصيرة وواضحة.

## المرجع

انسخه، واملا اللي بين الأقواس، وابعته لClaude أو أي ذكاء اصطناعي. كل ما تملا السياق أكتر، الرد بيبقى أدق.

ROLE: Act as [the expert you need, e.g. "a senior marketing copywriter"].
CONTEXT: I am [who you are]. This is for [project / business / situation]. The audience is [who will read or use it].
GOAL: I need [the exact result], so that [why it matters / what happens next].
INPUT: Here is what I have: [paste notes, data, links, examples].
CONSTRAINTS: [length, tone, language/dialect, format, what to avoid, deadline].
EXAMPLE OF GOOD: [paste one example you like, or describe it].
OUTPUT FORMAT: [bullet list / table / email / code / 3 options to choose from].
Before you answer: ask me up to 3 questions if anything important is missing. Then give the answer, and finish with one line on what I should check before using it.
