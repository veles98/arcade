---
name: voice-to-reel
description: Turns a voice recording into a finished vertical reel: cleans the audio, times every word with Whisper, builds animated scenes and word-by-word captions with HyperFrames, and renders it. Use when the user wants a reel or short video made from their voice.
---

# صوتك يصير ريل

تسجيل صوتك يصير ريل بكابشن كلمة كلمة وحركة، بدون برنامج مونتاج.

## طريقة الشغل
- المرجع تحت هو الطريقة اللي استخدمها أنس (@anas.ai.ar) في الريل. طبّقها على طلب المستخدم.
- أي شي بين قوسين مربعة [مثل كذا] يتبدّل بكلام المستخدم. إذا ناقص، اسأله سؤال واحد قصير قبل ما تبدأ.
- رد بلهجة المستخدم، وخل الخطوات قصيرة وواضحة.
- هذا السكيل يحتاج Claude Code لأنه يشغّل أوامر ويطلّع ملفات. قل للمستخدم كل أمر قبل ما تشغّله.

## المرجع

تحتاج Claude Code بس، والباقي يثبّته بنفسه مجانًا. افتحه في مجلد فاضي، وحط فيه تسجيل صوتك voice.m4a، والصق الأمر هذا وغيّر اللي بين القوسين.

أبي ريل طولي 1080×1920 بـ30 إطار من تسجيل صوتي voice.m4a، بدون أي برنامج مونتاج.
١) ثبّت اللي ناقص: FFmpeg و Whisper (faster-whisper) و HyperFrames (npx hyperframes). قل لي كل أمر قبل ما تشغله.
٢) نظّف الصوت بـ FFmpeg: شيل الضجة، وقص السكتات الطويلة (أكثر من ربع ثانية)، وارفع الصوت لـ -14 LUFS.
٣) طلّع كل كلمة بوقتها بـ Whisper (عربي)، واحفظها في words.json.
٤) ابنِ الفيديو بـ HyperFrames: خلفية [مثلا: أسود مع ذهبي]، كل كلمة تطلع على الشاشة بنفس لحظة نطقها، والكلمة المهمة بلون مختلف.
٥) لكل فكرة في كلامي مشهد: [اكتب أفكارك، كل فكرة سطر]. الأشياء تتحرك وحدها، والتنقل بين المشاهد زووم ناعم مو قص.
٦) حط موسيقى خفيفة مجانية الترخيص تحت الصوت، تنخفض لما أتكلم.
٧) قبل الرندر النهائي طلّع ٨ صور من نص الفيديو، وانتقدها كأنك مخرج: هل الحروف العربية متصلة؟ هل الكلام طالع برّا الشاشة؟ وعدّل.
٨) طلّع final.mp4 جاهز للنشر.
لو ناقصك شي اسألني قبل ما تبدأ.

النسخة الإنجليزية (أدق مع Claude Code):

Make me a vertical Instagram reel (1080x1920, 30fps) from my voice recording voice.m4a in this folder. No editing apps.
1) Install what's missing: FFmpeg, faster-whisper (Python), HyperFrames (npx hyperframes). Tell me each command before running it.
2) FFmpeg: denoise the voice, cut silences longer than 0.25s, normalize to -14 LUFS.
3) faster-whisper: transcribe in Arabic with word timestamps, save words.json.
4) HyperFrames: build the video. Dark background with gold accents. Show each word on screen exactly when I say it, key word in gold. One scene per idea, elements move on their own, smooth zoom transitions instead of hard cuts. Arabic must be connected and right-to-left.
5) Add a soft royalty-free music bed under the voice, ducked while I speak.
6) Before the final render, export 8 frames, review them like an art director (broken Arabic? text off-screen? empty frames?) and fix.
7) Render final.mp4 ready to post. Ask me if anything is missing.
