---
name: motion-kit
description: Builds a reusable motion-graphics kit (Arabic titles with shine, self-drawing icons, cards, transitions, particles) and renders sample clips. Use when the user wants video effects, motion graphics or animated titles.
---

# كِت موشن جرافيكس

يبني لك كِت موشن جرافيكس: عناوين عربية، وأيقونات، وانتقالات.

## طريقة الشغل
- المرجع تحت هو الطريقة اللي استخدمها أنس (@anas.ai.ar) في الريل. طبّقها على طلب المستخدم.
- أي شي بين قوسين مربعة [مثل كذا] يتبدّل بكلام المستخدم. إذا ناقص، اسأله سؤال واحد قصير قبل ما تبدأ.
- رد بلهجة المستخدم، وخل الخطوات قصيرة وواضحة.
- هذا السكيل يحتاج Claude Code لأنه يشغّل أوامر ويطلّع ملفات. قل للمستخدم كل أمر قبل ما تشغّله.

## المرجع

الصقه في Claude Code داخل مجلد فاضي: يبني لك كِت موشن جرافيكس (عناوين عربية بلمعة ذهبية، أيقونات ترسم نفسها، بطاقات، انتقالات، جزيئات، زر متابعة) ويصدّر ريل 1080x1920.

أنت مصمم موشن جرافيكس ومبرمج. ابنِ لي في هذا المجلد «كِت» موشن جرافيكس قابل لإعادة الاستخدام لريلز عمودية، بـ HTML + JavaScript، ويتصدّر فيديو 1080x1920 فريم-بفريم عن طريق Chrome بدون واجهة (headless) + ffmpeg.

الهيكل المطلوب:
- lib/motion.js — مكتبة المكونات (بدون أي مكتبات خارجية).
- lib/motion.css — الألوان والخطوط والثيمات.
- lib/fonts/ — خطوط عربية مجانية (OFL) مثل Alexandria و IBM Plex Sans Arabic، حمّلها من Google Fonts وحطها محلياً.
- demo.html + demo.reel.js — ريل تجريبي 20 ثانية يستخدم كل المكونات.
- render.py — يصدّر الصور والفيديو.
- GUIDE.md — شرح مختصر بالعربي: كيف أسوي ريل جديد في 5 خطوات.

قواعد المحرك (مهمة جداً):
1. الوقت حتمي: كل شي يُحسب من دالة واحدة renderAt(t) بالثواني. ممنوع requestAnimationFrame و CSS animations و setTimeout للحركة. نفس t = نفس الصورة دائماً.
2. عرّف window.__renderAt(t) تُرجع Promise تنحل بعد ما تجهز الصور والخطوط (document.fonts.ready + decode للصور).
3. المسرح 1080x1920 ثابت، ويتصغّر في المتصفح للمعاينة فقط (scale بـ CSS). منطقة آمنة: النصوص بين y=240 و y=1680.
4. دوال تسهيل (easing) بـ cubic-bezier حقيقي: keynote (0.2,0.8,0.2,1) افتراضي، settle (0.16,1,0.3,1) للهبوط، swift (0.65,0,0.35,1) للمسح، exit (0.55,0,0.75,0.2) للخروج. ودالة ramp(t, start, duration, ease).
5. العشوائية بـ seed ثابت (مثلاً LCG) عشان الجزيئات تطلع نفسها في كل رندر.
6. العربي: dir="rtl"، والنص HTML عادي (المتصفح يشكّل الحروف صح). لا تقسم الكلمة العربية لحروف أبداً (يكسر الوصل)؛ الحركة تكون على مستوى الكلمة أو السطر.

المكونات (API بسيط وواضح):
R = Motion.reel({ dur, fps: 30, base: 'name' })
R.scene(name, t0, t1, { theme, enter: { type, d } }, s => { ... })
داخل المشهد:
1. s.title({ text: 'سطر أول|سطر فيه *الكلمة*', at, y }) — عنوان حركي: كل كلمة تطلع من تحت مع blur خفيف وتأخير 60ms بين الكلمات، والكلمة بين نجمتين تتلوّن ذهبي (#F3C766) مع «لمعة» ذهبية تمسح عليها من اليمين لليسار (linear-gradient متحرك بـ background-clip:text) بعد ما تستقر. | تعني سطر جديد.
2. s.icon({ name, at, x, y, size }) — أيقونات خطية SVG (stroke فقط، سماكة 2.5، أطراف دائرية) ترسم نفسها بـ stroke-dasharray/dashoffset خلال 0.8 ث، ثم توهج خفيف. جهّز 12 أيقونة على الأقل: prompt, code, camera, light, gamepad, check, cross, book, cube, browser, scissors, wave.
3. s.iconRow([{icon,label}...], { at, y }) — صف أيقونات بتسميات، تطلع بالتتابع.
4. s.card({ at, index, total, title, body, from: 'right' }) — بطاقة زجاجية داكنة بحواف دائرية 28px وظل ناعم، تدخل بانزلاق مع motion blur حقيقي: ارسم 6 نسخ شفافة متأخرة زمنياً (ghost trail) أو استخدم filter: blur أفقي يتناسب مع السرعة، ويختفي لما توقف. فيها رقم «١/٣» بأرقام عربية.
5. s.particles({ count: 60, at, color: 'gold' }) — جزيئات غبار ذهبي تطفو ببطء مع وميض، على canvas، حتمية بالـ seed.
6. s.counter({ from, to, at, d, suffix }) — رقم يعدّ مع تسهيل.
7. s.endCTA({ keyword, offer, reason, at, followAt }) — بطاقة النهاية: «اكتب [keyword] بالتعليقات» + سطر العرض، ثم زر «متابعة» يطلع بنبضة (scale 0.9→1.06→1) ومؤشر يد/إصبع ينزل ويضغطه فيتحول الزر لـ «تمت المتابعة ✓» بلون ذهبي، وتحته سبب المتابعة.
8. R.captions([[word, start, end], ...], { y }) — كابشن كلمة-بكلمة للريلز اللي فيها صوت، الكلمة الحالية ذهبية.

الانتقالات بين المشاهد (enter.type):
- colourSwap — المشهد الجديد يدخل بلون خلفية مختلف بمسح أفقي حاد مع انزلاق بسيط للمحتوى.
- circleWipe — دائرة تكبر من نقطة (x,y) بـ clip-path: circle() مع حافة ذهبية رفيعة تلحق الدائرة.
- zoomThrough — المشهد القديم يكبر لـ 3x ويختفي مع blur وكأن الكاميرا دخلت فيه، والجديد يطلع من 0.8x.
- cardPush — المشهد الجديد يدفع القديم لفوق كأنها بطاقات.
كل انتقال مدته d (افتراضي 0.7 ث) وبتسهيل swift.

الثيمات في motion.css: black (خلفية #050507 مع إضاءة ذهبية خفيفة من فوق)، umber (بني غامق دافئ)، paper (فاتح #F5F2EA بنص داكن). لون تمييز واحد فقط: الذهبي. حبيبات (grain) خفيفة جداً فوق كل شي ب SVG noise ثابت.

render.py:
- يستخدم Chrome/Chromium headless عبر Playwright (pip install playwright ثم playwright install chromium) — أو Chrome DevTools Protocol مباشرة لو Playwright مو متوفر.
- viewport 1080x1920, deviceScaleFactor 1.
- python render.py demo.html stills 0 1 3 5 8 → يحفظ صور في _qa/ ويركّبها في _qa/sheet.png (شبكة) عشان أراجع قبل الرندر.
- python render.py demo.html all → لكل فريم: await page.evaluate("t => window.__renderAt(t)", t) ثم screenshot بصيغة PNG، ويرسله مباشرة لـ ffmpeg عبر stdin (image2pipe) بدون ما يحفظ الفريمات على القرص.
- ffmpeg: -c:v libx264 -preset slow -crf 16 -pix_fmt yuv420p -r 30 -movflags +faststart → name.mp4، ونسخة ثانية للويب أقل من 10MB (crf 23 أو bitrate محسوب)، ولو فيه ملف voice.wav أو music.mp3 في المجلد يدمجه (الموسيقى -18dB تحت الصوت).
- يطبع التقدم والوقت المتوقع، ويوقف بخطأ واضح لو ffmpeg مو موجود.

demo.reel.js (20 ث): هوك بعنوان ذهبي + أيقونة prompt ← 3 بطاقات مرقمة بانتقال circleWipe ثم colourSwap ← صف أيقونات + عدّاد ← جزيئات ← endCTA بانتقال zoomThrough. النصوص عربية وقصيرة (≤ 6 كلمات للسطر).

معايير الجودة (افحصها بنفسك على الـ sheet قبل ما تقول خلصت):
- الفريم الأول فيه الهوك مباشرة (ما يبدأ من أسود).
- ما فيه نص طالع برا المنطقة الآمنة، ولا حرف عربي مقطوع أو منفصل.
- الحركة هادية وفخمة: ما فيه ارتداد مبالغ، ولا وميض أحمر/أبيض، ولا إيموجي على الشاشة.
- رندر نفس الفريم مرتين يعطي نفس الصورة بالضبط.

ابدأ بكتابة الملفات كلها، ثم شغّل stills وراجع الـ sheet وصلّح، ثم شغّل all. لو ناقصك أداة (Python, ffmpeg, Chrome) قول لي أمر التثبيت قبل ما تكمل. في الأخير اعطني سطرين: كيف أعدل demo.reel.js لريل جديد، وأمر الرندر.
