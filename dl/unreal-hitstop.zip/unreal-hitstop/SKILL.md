---
name: unreal-hitstop
description: Adds hit-stop (a short freeze on impact) to melee hits in Unreal Engine using CustomTimeDilation. Use when the user wants combat hits to feel heavier in Unreal.
---

# Hit-stop في Unreal

يضيف Hit-stop للضربات في Unreal عشان تحسها.

## طريقة الشغل
- المرجع تحت هو الطريقة اللي استخدمها أنس (@anas.ai.ar) في الريل. طبّقها على طلب المستخدم.
- أي شي بين قوسين مربعة [مثل كذا] يتبدّل بكلام المستخدم. إذا ناقص، اسأله سؤال واحد قصير قبل ما تبدأ.
- رد بلهجة المستخدم، وخل الخطوات قصيرة وواضحة.
- هذا السكيل يحتاج Claude Code لأنه يشغّل أوامر ويطلّع ملفات. قل للمستخدم كل أمر قبل ما تشغّله.

## المرجع

Unreal Engine 5 — C++

هلا! هذا كود الـ Hit-stop كامل (Unreal Engine 5 - C++) 👇

// ===== Hero.h (داخل class AHero) =====
UPROPERTY() TObjectPtr<AActor> HitVictim;
FTimerHandle H;
void StartHitStop(AActor* Victim, float Seconds = 0.08f);
void EndHitStop();

// ===== Hero.cpp =====
void AHero::StartHitStop(AActor* Victim, float Seconds)
{
    HitVictim = Victim;
    CustomTimeDilation = 0.05f;                              // المهاجم (this) شبه واقف
    if (HitVictim) HitVictim->CustomTimeDilation = 0.05f;    // والعدو بعد
    // تايمر العالم ما يتأثر بـ CustomTimeDilation حق الأكتر، فـ 0.08 = 80ms فعلية
    GetWorldTimerManager().SetTimer(H, this, &AHero::EndHitStop, Seconds, false);
}

void AHero::EndHitStop()
{
    CustomTimeDilation = 1.f;
    if (HitVictim) HitVictim->CustomTimeDilation = 1.f;
    HitVictim = nullptr;
}

طريقة الاستخدام:
1) نادِ StartHitStop(TheEnemy) لحظة ما الضربة تصيب (من AnimNotify أو بعد ما تطبّق الضرر).
2) الضربة الخفيفة 0.05–0.08، الثقيلة 0.12–0.15. لو تبي تجمّد العالم كله استخدم UGameplayStatics::SetGlobalTimeDilation، بس انتبه إن التايمر بعدها يمشي بالوقت المبطّأ.
