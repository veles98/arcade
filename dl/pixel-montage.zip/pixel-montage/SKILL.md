---
name: pixel-montage
description: Turns a voice-over script into a series of same-style retro pixel-art image prompts, one per sentence, for a pixel montage video. Use when the user wants pixel-art visuals for a script or reel.
---

# مونتاج البكسل

يحوّل كلامك لصور بكسل بنفس الستايل، صورة لكل جملة.

## طريقة الشغل
- المرجع تحت هو الطريقة اللي استخدمها أنس (@anas.ai.ar) في الريل. طبّقها على طلب المستخدم.
- أي شي بين قوسين مربعة [مثل كذا] يتبدّل بكلام المستخدم. إذا ناقص، اسأله سؤال واحد قصير قبل ما تبدأ.
- رد بلهجة المستخدم، وخل الخطوات قصيرة وواضحة.

## المرجع

الصقه في Gemini، وغيّر المشهد بين القوسين كل مرة. نفس الستايل والألوان يطلع في كل صورة. حط لكل جملة في كلامك صورة، ورتّبها في CapCut.

Create an image: vertical 9:16 retro pixel-art collage illustration, dark olive green background with soft spotlight vignette and film grain, [وصف المشهد بالإنجليزي، مثال: a beige 1990s computer monitor showing three red error windows], chunky pixel-art style, limited palette olive green, red, cream, black, no text.

للصورة الثانية وما بعدها ابدأ بـ: Same exact style as the previous image.

تبي تحرّك الأجزاء لحالها (يد، شاشة، ساعة)؟ اطلب كل قطعة لحالها وأضف في آخر الوصف:
isolated on a flat pure green #00FF00 background, no shadow, no vignette, no grain
وبعدها شيل الأخضر في CapCut (Chroma key) وحرّك كل قطعة.
