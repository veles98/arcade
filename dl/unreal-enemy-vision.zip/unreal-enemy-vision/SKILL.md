---
name: unreal-enemy-vision
description: Implements enemy line-of-sight in Unreal Engine (view cone plus LineTrace, or AIPerception sight). Use when the user wants enemies to see or detect the player.
---

# العدو شافك؟ في Unreal

يخلي العدو يشوفك بمخروط نظر وشعاع، في Unreal.

## طريقة الشغل
- المرجع تحت هو الطريقة اللي استخدمها أنس (@anas.ai.ar) في الريل. طبّقها على طلب المستخدم.
- أي شي بين قوسين مربعة [مثل كذا] يتبدّل بكلام المستخدم. إذا ناقص، اسأله سؤال واحد قصير قبل ما تبدأ.
- رد بلهجة المستخدم، وخل الخطوات قصيرة وواضحة.
- هذا السكيل يحتاج Claude Code لأنه يشغّل أوامر ويطلّع ملفات. قل للمستخدم كل أمر قبل ما تشغّله.

## المرجع

Unreal Engine 5 — C++

هلا! هذا كود "العدو يشوفك؟" كامل (Unreal Engine 5 - C++) 👇

// ===== EnemyCharacter.h (داخل class AEnemyCharacter) =====
UPROPERTY(EditAnywhere) float SightRange = 1500.f;     // أبعد مسافة يشوف لها (سم)
UPROPERTY(EditAnywhere) float HalfAngleDeg = 35.f;     // نص زاوية المخروط
bool CanSee(const AActor* Player) const;

// ===== EnemyCharacter.cpp =====
bool AEnemyCharacter::CanSee(const AActor* Player) const
{
    if (!Player) return false;

    FVector Eye; FRotator EyeRot;
    GetActorEyesViewPoint(Eye, EyeRot);                 // مكان العين واتجاهها
    const FVector Forward   = EyeRot.Vector();
    const FVector PlayerLoc = Player->GetActorLocation();
    const FVector ToPlayer  = PlayerLoc - Eye;

    // 0) بعيد؟
    if (ToPlayer.SizeSquared() > FMath::Square(SightRange)) return false;

    // 1) داخل المخروط؟
    const float CosHalfAngle = FMath::Cos(FMath::DegreesToRadians(HalfAngleDeg));
    const float Dot = FVector::DotProduct(Forward, ToPlayer.GetSafeNormal());
    if (Dot < CosHalfAngle) return false;

    // 2) فيه جدار بالنص؟
    FCollisionQueryParams Params(SCENE_QUERY_STAT(EnemySight), false, this); // تجاهل العدو نفسه
    FHitResult Hit;
    GetWorld()->LineTraceSingleByChannel(Hit, Eye, PlayerLoc, ECC_Visibility, Params);
    return !Hit.bBlockingHit || Hit.GetActor() == Player;
}

طريقة الاستخدام:
1) نادِ CanSee(Player) كل 0.1–0.2 ثانية بتايمر (مو كل فريم) عشان الأداء.
2) لو رجعت true: العدو ينتبه (علامة "!") ويبدأ يلاحق.
3) حيلة: سوّ الـ Trace لراس اللاعب ولوسطه، لو واحد منهم واضح = شافه (ما يختفي اللاعب لو بس رجوله ورا صندوق).
4) لو تبي الجاهز: UAIPerceptionComponent + UAISenseConfig_Sight يسوي نفس الشي داخليًا.
