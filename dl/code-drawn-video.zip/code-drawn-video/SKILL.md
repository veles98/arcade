---
name: code-drawn-video
description: Writes and runs a Python script that draws a complete vertical video entirely in code (sky, planets, meteors) and renders it with FFmpeg, with preview frames first. Use when the user wants a video drawn by code or an astronomy or space visual.
---

# فيديو مرسوم بالكود

فيديو كامل مرسوم بالكود، بدون أي صورة أو مقطع جاهز.

## طريقة الشغل
- المرجع تحت هو الطريقة اللي استخدمها أنس (@anas.ai.ar) في الريل. طبّقها على طلب المستخدم.
- أي شي بين قوسين مربعة [مثل كذا] يتبدّل بكلام المستخدم. إذا ناقص، اسأله سؤال واحد قصير قبل ما تبدأ.
- رد بلهجة المستخدم، وخل الخطوات قصيرة وواضحة.
- هذا السكيل يحتاج Claude Code لأنه يشغّل أوامر ويطلّع ملفات. قل للمستخدم كل أمر قبل ما تشغّله.

## المرجع

الفيديو كله مرسوم بالكود، بدون أي صورة أو مقطع جاهز. الخطوات:

نزّل Claude Code وافتحه داخل مجلد فاضي.
الصق البرومبت اللي تحت، وخلّه يثبّت Python و FFmpeg لو ناقصين.
بيطلّع لك ٦ صور تجربة أول. عدّل عليها بكلامك (مثلا: القمر أكبر، الشهب أسرع، لون أدفى).
لما تعجبك الصور، قل له: «طلّع الفيديو النهائي»، ويعطيك final.mp4 جاهز للنشر.

Write one Python script sky.py (numpy, OpenCV, Pillow, then FFmpeg) that renders a 24-second vertical video, 1080x1920 at 30fps, drawn entirely by code, with no images or footage.
- A dark terminal window frame, with the command line at the top.
- Scene 1 (0-8s): Mars and Jupiter moving close over a desert horizon, about 1 degree apart, with simple planet textures.
- Scene 2 (8-15s): Leonid meteors streaking out of the radiant in the Leo constellation, as a time-lapse with glowing trails.
- Scene 3 (15-24s): a giant full moon rising behind a black city skyline, with light through clouds.
- A twinkling starfield, soft bloom glow, and smooth zoom-through transitions between scenes.
- An Arabic title for each scene in a gold pill, connected and right-to-left.
- Soft ambient music, with a light whoosh on each transition.
Install anything missing and tell me each command before running it.
Render 6 test frames first, show them to me, fix the issues, then export final.mp4.
