---
name: pixel-animals
description: Writes matching pixel-art sprite prompts for a list of animals (or any characters), a 9:16 pixel background prompt, and CapCut steps to animate them into a short video. Use when the user wants a pixel-art animals or characters video.
---

# فيديو حيوانات البكسل

يكتب لك برومبتات حيوانات بكسل بنفس الستايل، وخطوات تحريكها في CapCut.

## طريقة الشغل
- المرجع تحت هو الطريقة اللي استخدمها أنس (@anas.ai.ar) في الريل. طبّقها على طلب المستخدم.
- أي شي بين قوسين مربعة [مثل كذا] يتبدّل بكلام المستخدم. إذا ناقص، اسأله سؤال واحد قصير قبل ما تبدأ.
- رد بلهجة المستخدم، وخل الخطوات قصيرة وواضحة.

## المرجع

نفس الفيديو اللي في الريل، بخطوتين: ChatGPT يرسم، وCapCut يحرّك. كل البرومبتات بالإنجليزي عشان النتيجة تطلع أدق، انسخها مثل ما هي.

١. ارسم أول حيوان
افتح ChatGPT (مجاني)، محادثة جديدة، والصق هذا. غيّر اللي بين القوسين لأي حيوان، بالإنجليزي.

Pixel art sprite in the style of 1980s video games, 64x64 pixels, full body side view walking to the right, [a small brown hamster], transparent background, no text, no shadow.

٢. باقي الحيوانات بنفس الستايل
في نفس المحادثة، لكل حيوان جديد الصق هذا وغيّر اللي بين القوسين. كذا تطلع كلها بنفس الحجم والألوان.

Same exact style, size and pixel scale as the previous image: [a big grey elephant], walking to the right, transparent background, no text.

٣. الخلفية
في نفس المحادثة، الصق هذا للخلفية الطولية.

Vertical 9:16 pixel art background in the same style: night sky with stars and a full moon, grass ground at the bottom and a small sea on the right, calm colors, no text, no characters.

٤. التحريك في CapCut
١) افتح مشروع جديد طولي 9:16، وحط صورة الخلفية.
٢) «تراكب» (Overlay): أضف صورة كل حيوان فوق الخلفية.
٣) لكل حيوان: حطه برا الشاشة على اليسار، واضغط Keyframe، وبعد نص ثانية حرّكه لمكانه، وKeyframe ثاني. كذا يدخل ماشي.
٤) خلّ كل حيوان يدخل بعد اللي قبله بثانية تقريبًا.
٥) «نص»: اكتب فوق كل حيوان الرقم (مثلًا: ٢ سنة)، وخله يطلع بحركة Pop.
٦) حط موسيقى وصوت «بوب» مع كل حيوان، وصدّر 1080p.
الأرقام اللي في الريل (تقريبية)
همستر ٢ سنة · كلب ١٢ · فيل ٦٠ · إنسان ٧٣ (متوسط العمر في العالم) · قرش غرينلاند لين ٤٠٠ سنة تقريبًا (دراسة في مجلة Science سنة ٢٠١٦).
