---
name: phone-ui-montage
description: Turns a voice recording into a vertical reel where every sentence is told by a different phone-UI screen (search bar, home screen, chat bubble, copy/paste menu, radar) joined by match cuts, with word-by-word text and UI sound effects, rendered with HyperFrames. Use when the user wants a phone-UI kinetic montage from their voice.
---

# مونتاج بشاشات الموبايل من غير برنامج

كل جملة من كلامك تطلع من شاشة موبايل، بدون برنامج مونتاج.

## طريقة الشغل
- المرجع تحت هو الطريقة اللي استخدمها أنس (@anas.ai.ar) في الريل. طبّقها على طلب المستخدم.
- أي شي بين قوسين مربعة [مثل كذا] يتبدّل بكلام المستخدم. إذا ناقص، اسأله سؤال واحد قصير قبل ما تبدأ.
- رد بلهجة المستخدم، وخل الخطوات قصيرة وواضحة.
- هذا السكيل يحتاج Claude Code لأنه يشغّل أوامر ويطلّع ملفات. قل للمستخدم كل أمر قبل ما تشغّله.

## المرجع

حط تسجيل صوتك voice.m4a في مجلد فاضي، وافتح فيه Claude Code، والصق الرسالة دي.

Make a vertical reel (1080x1920, 30fps) from my voice recording voice.m4a in this folder, with no editing apps.
1) Install anything missing (FFmpeg, faster-whisper, HyperFrames via npx hyperframes). Tell me each command before running it.
2) Transcribe the voice with word timestamps (my language: [Arabic / English]) into words.json.
3) Tell every sentence with a different phone-UI screen, full screen: a search bar typing the words, a home screen whose app icons fly away, a chat bubble being sent, a copy/paste menu over scrolling code, a "Find My" style radar that counts down to "here". Use generic icons, no real brand logos.
4) Each word appears exactly when I say it; the key word is highlighted.
5) Join the screens with match cuts (a circle becomes the next circle, a bubble becomes the next element), smooth and eased, never random wipes.
6) Add UI sound effects on every action (typing, send, delete, ping) and a soft royalty-free music bed ducked under my voice.
7) End with a card: [your call to action].
8) Before the final render, export 8 frames, review them like an art director (broken text, text off screen, empty frames) and fix them. Then render final.mp4.
